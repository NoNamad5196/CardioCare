# 최종 모델 선택 특성

- age
- trestbps
- chol
- thalach
- oldpeak
- sex_0.0
- sex_1.0
- cp_2.0
- cp_3.0
- cp_4.0
- exang_0.0
- exang_1.0
- thal_3.0
- thal_7.0
